# E2B Execution Service Deployment Guide

## Overview
The E2B Execution Service is a separate Node.js service that provides HTTP endpoints for executing Python code using E2B Code Interpreter. This service solves the Supabase Edge Functions limitation by offloading E2B operations to a dedicated service.

## Architecture
```
[Supabase Edge Functions] 
    ↓ HTTP requests
[E2B Execution Service]
    ↓ @e2b/code-interpreter SDK
[E2B Sandboxes]
    ↓ Python code execution
[Results returned to Edge Functions]
```

## Prerequisites
- Node.js 18+ 
- E2B API key
- Environment variables configured

## Deployment Options

### Option 1: Docker Deployment (Recommended)

#### Build and run locally:
```bash
# Clone and navigate to service directory
cd e2b-execution-service

# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env

# Build Docker image
docker build -t e2b-execution-service .

# Run container
docker run -d \
  --name e2b-service \
  --env-file .env \
  -p 3000:3000 \
  e2b-execution-service
```

#### Deploy to cloud providers:

**Vercel:**
```bash
npm i -g vercel
vercel --prod
```

**Railway:**
```bash
railway login
railway init
railway up
```

**DigitalOcean App Platform:**
```bash
# Upload to GitHub and connect in DigitalOcean dashboard
```

### Option 2: Direct Node.js Deployment

```bash
# Install dependencies
npm install

# Start service
npm start
```

### Option 3: Serverless Deployment (Vercel Functions)

Create `vercel.json`:
```json
{
  "functions": {
    "src/server.js": {
      "runtime": "nodejs18.x"
    }
  }
}
```

## Environment Variables

Create `.env` file:
```env
E2B_API_KEY=your_e2b_api_key_here
SERVICE_AUTH_TOKEN=your_service_auth_token_here
PORT=3000
```

## API Endpoints

### Health Check
```bash
GET /health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-10-29T00:19:43.000Z",
  "service": "E2B Execution Service"
}
```

### Execute Python Code
```bash
POST /execute
Authorization: Bearer YOUR_SERVICE_AUTH_TOKEN
Content-Type: application/json

{
  "pythonCode": "import json\nprint(json.dumps({'result': 'success'}))",
  "timeout": 60000,
  "sandboxId": "optional-custom-id"
}
```

### Batch Execution
```bash
POST /execute-batch
Authorization: Bearer YOUR_SERVICE_AUTH_TOKEN
Content-Type: application/json

{
  "pythonCodes": [
    "import json\nprint(json.dumps({'result': 'success', 'id': 1}))",
    "import json\nprint(json.dumps({'result': 'success', 'id': 2}))"
  ],
  "timeout": 60000
}
```

## Integration with Supabase

### 1. Deploy the E2B service to your preferred platform
### 2. Update Supabase Edge Functions to call the service

Example Supabase function update:
```typescript
// OLD (broken):
import { Sandbox } from "npm:@e2b/code-interpreter";
const sandbox = await Sandbox.create();

// NEW (working):
const e2bServiceUrl = Deno.env.get('E2B_SERVICE_URL');
const authToken = Deno.env.get('E2B_SERVICE_AUTH_TOKEN');

const response = await fetch(`${e2bServiceUrl}/execute`, {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({ pythonCode: yourPythonCode })
});

const result = await response.json();
```

## Testing

### Local Testing:
```bash
# Start service
npm start

# Test health endpoint
curl http://localhost:3000/health

# Test Python execution
curl -X POST http://localhost:3000/execute \
  -H "Authorization: Bearer your-token" \
  -H "Content-Type: application/json" \
  -d '{"pythonCode": "import json\nprint(json.dumps({\"test\": \"success\"}))"}'
```

### Integration Testing:
1. Deploy service to platform
2. Test from Supabase functions
3. Verify Python execution in E2B sandboxes
4. Check error handling and timeouts

## Monitoring

### Health Monitoring
- Monitor `/health` endpoint
- Check service logs for errors
- Monitor E2B API usage

### Logging
The service logs:
- Python execution requests
- E2B sandbox creation/destruction  
- Execution results and errors
- Performance metrics

## Security

### Authentication
- Service requires Bearer token authentication
- Token validated against SERVICE_AUTH_TOKEN environment variable
- Use strong, randomly generated tokens

### Rate Limiting (Recommended)
Add rate limiting middleware:
```javascript
const rateLimit = require('express-rate-limit');
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/execute', limiter);
```

### SSL/TLS
Deploy behind HTTPS proxy or use platform SSL (Vercel, Railway, etc.)

## Troubleshooting

### Common Issues:
1. **E2B API Key Error**: Verify key is set and valid
2. **Authentication Error**: Check SERVICE_AUTH_TOKEN matches
3. **Timeout**: Increase timeout in request or check E2B limits
4. **Memory Issues**: Monitor sandbox memory usage

### Debug Mode:
Set `NODE_ENV=development` for detailed logs

## Cost Optimization

### E2B Usage:
- Monitor sandbox creation frequency
- Use sandbox reuse where appropriate
- Implement timeout limits
- Monitor API usage in E2B dashboard

### Service Scaling:
- Use horizontal scaling for high load
- Implement connection pooling
- Add caching for repeated computations

## Success Metrics

✅ **Service successfully deployed when:**
- Health endpoint returns 200
- Python code executes in E2B sandboxes
- Supabase functions can call service
- All three functions (market-data, ai-prediction, profitability) work

✅ **Integration successful when:**
- Edge Functions call E2B service via HTTP
- Python computations execute in real E2B sandboxes
- Kelly Criterion, market analysis, and AI predictions work
- No more WORKER_ERROR on deployed functions