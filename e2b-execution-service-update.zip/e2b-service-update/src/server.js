const express = require('express');
const cors = require('cors');
const { Sandbox } = require('@e2b/code-interpreter');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    // Verify token matches expected pattern
    if (token !== process.env.SERVICE_AUTH_TOKEN) {
        return res.status(403).json({ error: 'Invalid access token' });
    }

    next();
};

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'healthy', 
        timestamp: new Date().toISOString(),
        service: 'E2B Execution Service'
    });
});

// Execute Python code endpoint
app.post('/execute', authenticateToken, async (req, res) => {
    const { pythonCode, timeout = 60000, sandboxId } = req.body;

    if (!pythonCode) {
        return res.status(400).json({ error: 'pythonCode is required' });
    }

    let sandbox = null;

    try {
        console.log('Creating E2B sandbox...');
        
        // Create sandbox with optional ID
        if (sandboxId) {
            sandbox = await Sandbox.create(sandboxId);
        } else {
            sandbox = await Sandbox.create();
        }

        console.log('Executing Python code...');
        console.log('Python code length:', pythonCode.length);

        // Execute the Python code
        const execution = await sandbox.runCode(pythonCode, {
            onStdout: (data) => console.log('Python stdout:', data),
            onStderr: (data) => console.error('Python stderr:', data)
        });

        console.log('Execution completed successfully');
        
        // Parse stdout for JSON result
        let result = null;
        let rawOutput = execution.logs?.stdout || '';
        
        if (rawOutput) {
            try {
                // Try to parse as JSON (our Python code outputs JSON)
                const lines = rawOutput.split('\n').filter(line => line.trim());
                for (const line of lines) {
                    if (line.trim().startsWith('{') || line.trim().startsWith('[')) {
                        result = JSON.parse(line);
                        break;
                    }
                }
            } catch (parseError) {
                console.log('Could not parse JSON from stdout, returning raw output');
                result = { raw_output: rawOutput, parsed_error: 'JSON parsing failed' };
            }
        }

        const response = {
            success: true,
            result: result,
            logs: {
                stdout: execution.logs?.stdout || '',
                stderr: execution.logs?.stderr || ''
            },
            metrics: {
                executionTime: execution.metrics?.executionTime || 0,
                success: true
            }
        };

        console.log('Returning response:', JSON.stringify(response, null, 2));

        res.json(response);

    } catch (error) {
        console.error('E2B execution error:', error);

        const errorResponse = {
            success: false,
            error: {
                message: error.message,
                type: error.name || 'ExecutionError',
                details: error.stack
            },
            logs: {
                stdout: '',
                stderr: error.message
            },
            metrics: {
                success: false,
                executionTime: 0
            }
        };

        res.status(500).json(errorResponse);
    } finally {
        // Always cleanup sandbox
        if (sandbox) {
            try {
                await sandbox.kill();
                console.log('Sandbox closed successfully');
            } catch (closeError) {
                console.error('Error closing sandbox:', closeError);
            }
        }
    }
});

// Batch execution endpoint
app.post('/execute-batch', authenticateToken, async (req, res) => {
    const { pythonCodes, timeout = 60000 } = req.body;

    if (!pythonCodes || !Array.isArray(pythonCodes)) {
        return res.status(400).json({ error: 'pythonCodes array is required' });
    }

    const results = [];

    try {
        console.log(`Starting batch execution of ${pythonCodes.length} codes`);

        // Execute each Python code sequentially to avoid resource exhaustion
        for (let i = 0; i < pythonCodes.length; i++) {
            const pythonCode = pythonCodes[i];
            console.log(`Executing code ${i + 1}/${pythonCodes.length}`);

            try {
                const sandbox = await Sandbox.create();
                const execution = await sandbox.runCode(pythonCode, {
                    onStdout: (data) => console.log(`Code ${i + 1} stdout:`, data),
                    onStderr: (data) => console.error(`Code ${i + 1} stderr:`, data)
                });

                // Parse result
                let result = null;
                let rawOutput = execution.logs?.stdout || '';
                
                if (rawOutput) {
                    try {
                        const lines = rawOutput.split('\n').filter(line => line.trim());
                        for (const line of lines) {
                            if (line.trim().startsWith('{') || line.trim().startsWith('[')) {
                                result = JSON.parse(line);
                                break;
                            }
                        }
                    } catch (parseError) {
                        result = { raw_output: rawOutput, parsed_error: 'JSON parsing failed' };
                    }
                }

                results.push({
                    index: i,
                    success: true,
                    result: result,
                    logs: {
                        stdout: execution.logs?.stdout || '',
                        stderr: execution.logs?.stderr || ''
                    }
                });

                await sandbox.kill();
            } catch (error) {
                console.error(`Error in batch execution ${i + 1}:`, error);
                results.push({
                    index: i,
                    success: false,
                    error: {
                        message: error.message,
                        type: error.name || 'ExecutionError'
                    }
                });
            }
        }

        res.json({
            success: true,
            results: results,
            total: pythonCodes.length,
            successful: results.filter(r => r.success).length,
            failed: results.filter(r => !r.success).length
        });

    } catch (error) {
        console.error('Batch execution error:', error);
        res.status(500).json({
            success: false,
            error: {
                message: error.message,
                type: 'BatchExecutionError'
            }
        });
    }
});

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        service: 'E2B Execution Service',
        version: '1.0.0',
        endpoints: {
            health: '/health',
            execute: 'POST /execute',
            executeBatch: 'POST /execute-batch'
        },
        documentation: 'Send Python code to /execute with Authorization: Bearer <token>'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 E2B Execution Service running on port ${PORT}`);
    console.log(`📋 Health check: http://localhost:${PORT}/health`);
    console.log(`🐍 Execute Python: POST http://localhost:${PORT}/execute`);
    console.log(`📦 Batch execution: POST http://localhost:${PORT}/execute-batch`);
    
    if (!process.env.E2B_API_KEY) {
        console.error('⚠️  WARNING: E2B_API_KEY environment variable not set!');
    } else {
        console.log('✅ E2B_API_KEY configured');
    }
    
    if (!process.env.SERVICE_AUTH_TOKEN) {
        console.error('⚠️  WARNING: SERVICE_AUTH_TOKEN environment variable not set!');
    } else {
        console.log('✅ Service authentication configured');
    }
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('🛑 Received SIGINT, shutting down gracefully...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('🛑 Received SIGTERM, shutting down gracefully...');
    process.exit(0);
});