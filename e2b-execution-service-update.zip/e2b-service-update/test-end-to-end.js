#!/usr/bin/env node

/**
 * End-to-End E2B Integration Test
 * Tests the complete flow: Edge Functions → E2B Service → Real Python Execution
 */

const fs = require('fs');
const path = require('path');

// Configuration
const TEST_CONFIG = {
    serviceUrl: process.env.E2B_SERVICE_URL || 'http://localhost:3000',
    serviceAuth: process.env.E2B_SERVICE_AUTH_TOKEN || 'e2b_service_auth_token_2025_polymarket_hunter',
    supabaseUrl: process.env.SUPABASE_URL || 'https://skfvdshpdeudowrunxhe.supabase.co',
    supabaseKey: process.env.SUPABASE_ANON_KEY
};

/**
 * Test E2B Service Health
 */
const testServiceHealth = async () => {
    console.log('🏥 Testing E2B Service Health...\n');
    
    try {
        const response = await fetch(`${TEST_CONFIG.serviceUrl}/health`);
        const result = await response.json();
        
        console.log('✅ E2B Service Status:', response.status);
        console.log('📋 Response:', JSON.stringify(result, null, 2));
        
        return response.ok;
    } catch (error) {
        console.log('❌ Service Health Check Failed:', error.message);
        console.log('💡 Make sure the E2B service is deployed and running');
        return false;
    }
};

/**
 * Test Python Code Execution in E2B
 */
const testPythonExecution = async () => {
    console.log('\n🐍 Testing Python Execution in E2B...\n');
    
    const testPythonCode = `
import json
import numpy as np
from datetime import datetime

# Test basic calculations
def test_kelly_criterion():
    """Test Kelly Criterion calculation"""
    p = 0.6  # probability of winning
    b = 2.0  # odds (2:1 payout)
    kelly = (b * p - (1 - p)) / b
    return max(0.0, min(0.25, kelly))

# Test risk metrics
def test_risk_metrics():
    """Test risk metrics calculation"""
    returns = np.array([0.02, -0.01, 0.03, -0.02, 0.01])
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    sharpe_ratio = mean_return / std_return if std_return > 0 else 0.0
    
    return {
        'mean_return': round(mean_return, 4),
        'volatility': round(std_return * np.sqrt(252), 4),
        'sharpe_ratio': round(sharpe_ratio, 3)
    }

# Test market analysis
def test_market_analysis():
    """Test market data analysis"""
    market_data = {
        'question': 'Will Bitcoin reach $100,000 by 2025?',
        'currentPrice': 0.15,
        'volume24h': 50000,
        'liquidity': 25000,
        'category': 'crypto'
    }
    
    # Simple analysis
    volume_score = min(market_data['volume24h'] / 100000, 1.0)
    liquidity_score = min(market_data['liquidity'] / 50000, 1.0)
    market_score = (volume_score + liquidity_score) / 2
    
    return {
        'volume_score': round(volume_score, 3),
        'liquidity_score': round(liquidity_score, 3),
        'market_score': round(market_score, 3),
        'recommendation': 'BUY' if market_score > 0.6 else 'HOLD'
    }

# Execute tests
result = {
    'test_timestamp': datetime.now().isoformat(),
    'kelly_criterion': test_kelly_criterion(),
    'risk_metrics': test_risk_metrics(),
    'market_analysis': test_market_analysis(),
    'execution_environment': 'E2B_SANDBOX',
    'status': 'SUCCESS'
}

print(json.dumps(result))
`;

    try {
        const response = await fetch(`${TEST_CONFIG.serviceUrl}/execute`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${TEST_CONFIG.serviceAuth}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                pythonCode: testPythonCode,
                timeout: 60000
            })
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(`E2B execution failed: ${result.error?.message}`);
        }
        
        console.log('✅ Python Execution Successful');
        console.log('📊 Execution Time:', result.metrics?.executionTime, 'ms');
        console.log('📋 Result:', JSON.stringify(result.result, null, 2));
        
        // Validate the computation results
        const data = result.result;
        if (data.kelly_criterion && data.risk_metrics && data.market_analysis) {
            console.log('✅ All financial calculations working');
        }
        
        return true;
    } catch (error) {
        console.log('❌ Python Execution Failed:', error.message);
        return false;
    }
};

/**
 * Test MiniMax AI Integration
 */
const testMiniMaxAI = async () => {
    console.log('\n🤖 Testing MiniMax AI Integration...\n');
    
    const minimaxApiKey = process.env.MINIMAX_API_KEY;
    if (!minimaxApiKey) {
        console.log('⚠️  MINIMAX_API_KEY not available, skipping AI test');
        return true;
    }
    
    const aiTestCode = `
import json
import requests

def test_minimax_api():
    """Test MiniMax API integration"""
    api_key = "${minimaxApiKey}"
    
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    payload = {
        "model": "abab6.5s-chat",
        "messages": [
            {
                "role": "system",
                "content": "You are an expert in prediction markets and probability analysis. Always respond with valid JSON."
            },
            {
                "role": "user", 
                "content": "What is the probability that this test will succeed? Respond with JSON: {\\"probability\\": 0.0, \\"confidence\\": 0.0, \\"factors\\": [], \\"reasoning\\": \\"\\"}"
            }
        ],
        "max_tokens": 200,
        "temperature": 0.3
    }
    
    try:
        response = requests.post(
            'https://api.minimax.chat/v1/text/chatcompletion_v2',
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            ai_content = result['choices'][0]['message']['content']
            return {
                'status': 'success',
                'ai_response': ai_content,
                'response_time': 'N/A'
            }
        else:
            return {
                'status': 'error',
                'error': f'HTTP {response.status_code}',
                'message': response.text
            }
            
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e),
            'message': 'API call failed'
        }

# Test the API
result = test_minimax_api()
print(json.dumps(result))
`;

    try {
        const response = await fetch(`${TEST_CONFIG.serviceUrl}/execute`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${TEST_CONFIG.serviceAuth}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                pythonCode: aiTestCode,
                timeout: 60000
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.result.status === 'success') {
            console.log('✅ MiniMax AI Integration Working');
            console.log('🤖 AI Response:', result.result.ai_response);
        } else {
            console.log('⚠️  MiniMax AI Integration Result:', result.result.status);
            console.log('📋 Details:', result.result);
        }
        
        return true;
    } catch (error) {
        console.log('❌ MiniMax AI Test Failed:', error.message);
        return false;
    }
};

/**
 * Test Supabase Edge Functions Integration
 */
const testSupabaseIntegration = async () => {
    console.log('\n🔗 Testing Supabase Edge Functions Integration...\n');
    
    if (!TEST_CONFIG.supabaseKey) {
        console.log('⚠️  Supabase key not available, skipping Edge Function test');
        return true;
    }
    
    const functions = [
        'market-data-fetcher',
        'ai-prediction', 
        'profitability-scorer'
    ];
    
    const results = [];
    
    for (const functionName of functions) {
        try {
            console.log(`Testing ${functionName}...`);
            
            const response = await fetch(`${TEST_CONFIG.supabaseUrl}/functions/v1/${functionName}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${TEST_CONFIG.supabaseKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    // Add appropriate test data for each function
                    category: 'all',
                    page: 0,
                    limit: 5
                })
            });
            
            const result = await response.json();
            
            if (response.ok && !result.error) {
                console.log(`✅ ${functionName}: SUCCESS`);
                results.push({ function: functionName, status: 'success', data: result });
            } else {
                console.log(`❌ ${functionName}: FAILED`);
                console.log('Error:', result.error?.message || 'Unknown error');
                results.push({ function: functionName, status: 'failed', error: result.error });
            }
            
        } catch (error) {
            console.log(`❌ ${functionName}: ERROR - ${error.message}`);
            results.push({ function: functionName, status: 'error', error: error.message });
        }
    }
    
    const successCount = results.filter(r => r.status === 'success').length;
    console.log(`\n📊 Supabase Integration Summary: ${successCount}/${results.length} functions working`);
    
    return successCount === results.length;
};

/**
 * Generate Test Report
 */
const generateTestReport = (results) => {
    console.log('\n📋 E2B Integration Test Report');
    console.log('=' .repeat(50));
    
    const totalTests = Object.keys(results).length;
    const passedTests = Object.values(results).filter(r => r === true).length;
    
    console.log(`Overall Status: ${passedTests}/${totalTests} tests passed`);
    
    Object.entries(results).forEach(([test, passed]) => {
        const status = passed ? '✅ PASS' : '❌ FAIL';
        console.log(`${test}: ${status}`);
    });
    
    if (passedTests === totalTests) {
        console.log('\n🎉 ALL TESTS PASSED! E2B integration is working correctly.');
        console.log('🚀 Your Polymarket Profit Hunter is ready with real E2B execution!');
    } else {
        console.log('\n⚠️  Some tests failed. Please check the configuration and deployment.');
    }
    
    return passedTests === totalTests;
};

/**
 * Main Test Runner
 */
const runEndToEndTests = async () => {
    console.log('🧪 E2B Integration - End-to-End Testing');
    console.log('=' .repeat(60));
    console.log('Testing complete flow: Edge Functions → E2B Service → Python Execution');
    console.log('');
    
    const results = {
        service_health: await testServiceHealth(),
        python_execution: await testPythonExecution(),
        minimax_ai: await testMiniMaxAI(),
        supabase_integration: await testSupabaseIntegration()
    };
    
    const allPassed = generateTestReport(results);
    
    console.log('\n📝 Test Configuration Used:');
    console.log(`Service URL: ${TEST_CONFIG.serviceUrl}`);
    console.log(`Supabase URL: ${TEST_CONFIG.supabaseUrl}`);
    console.log(`Auth Token: ${TEST_CONFIG.serviceAuth.substring(0, 10)}...`);
    
    return allPassed;
};

// Run tests if called directly
if (require.main === module) {
    runEndToEndTests()
        .then(success => {
            process.exit(success ? 0 : 1);
        })
        .catch(error => {
            console.error('Test runner error:', error);
            process.exit(1);
        });
}

module.exports = {
    runEndToEndTests,
    testServiceHealth,
    testPythonExecution,
    testMiniMaxAI,
    testSupabaseIntegration
};